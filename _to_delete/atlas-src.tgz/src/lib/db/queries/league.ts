import { eq, and, asc, desc, sql, inArray } from 'drizzle-orm';
import type { NeonHttpDatabase } from 'drizzle-orm/neon-http';
import * as schema from '../schema';
import type { FixtureWithTeams } from '../queries';
import { hydrateFixtures } from '../queries-hydrate';
import { LIVE_CODES_ARRAY, FINISHED_CODES_ARRAY } from '@/lib/match-status';

// ── Types ──

export interface CompetitionRecord {
  id: number;
  slug: string;
  name: Record<string, string>;
  countryCode: string | null;
  type: string;
  logoUrl: string | null;
}

export interface LeagueCoverageRecord {
  standings: boolean | null;
  topScorers: boolean | null;
  topAssists: boolean | null;
  topCards: boolean | null;
  events: boolean | null;
  lineups: boolean | null;
  statisticsFixtures: boolean | null;
  statisticsPlayers: boolean | null;
  injuries: boolean | null;
  predictions: boolean | null;
}

export interface RoundInfo {
  roundNumber: number;
  round: string;
}

// ── Queries ──

export async function getCompetitionById(
  db: NeonHttpDatabase<typeof schema>,
  id: number,
): Promise<CompetitionRecord | null> {
  const rows = await db
    .select({
      id: schema.competitions.id,
      slug: schema.competitions.slug,
      name: schema.competitions.name,
      countryCode: schema.competitions.countryCode,
      type: schema.competitions.type,
      logoUrl: schema.competitions.logoUrl,
    })
    .from(schema.competitions)
    .where(eq(schema.competitions.id, id))
    .limit(1);

  return rows[0] ?? null;
}

export async function getLeagueCoverage(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  season: number,
): Promise<LeagueCoverageRecord | null> {
  const rows = await db
    .select({
      standings: schema.leagueCoverage.standings,
      topScorers: schema.leagueCoverage.topScorers,
      topAssists: schema.leagueCoverage.topAssists,
      topCards: schema.leagueCoverage.topCards,
      events: schema.leagueCoverage.events,
      lineups: schema.leagueCoverage.lineups,
      statisticsFixtures: schema.leagueCoverage.statisticsFixtures,
      statisticsPlayers: schema.leagueCoverage.statisticsPlayers,
      injuries: schema.leagueCoverage.injuries,
      predictions: schema.leagueCoverage.predictions,
    })
    .from(schema.leagueCoverage)
    .where(
      and(
        eq(schema.leagueCoverage.leagueId, competitionId),
        eq(schema.leagueCoverage.season, season),
      ),
    )
    .limit(1);

  return rows[0] ?? null;
}

export async function getCurrentSeasonYear(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
): Promise<number | null> {
  const rows = await db
    .select({ year: schema.seasons.year })
    .from(schema.seasons)
    .where(and(eq(schema.seasons.competitionId, competitionId), eq(schema.seasons.isCurrent, true)))
    .limit(1);

  return rows[0]?.year ?? null;
}

export async function getAvailableSeasons(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
): Promise<{ year: number; isCurrent: boolean; fixtureCount: number }[]> {
  const [rows, fixtureCountRows] = await Promise.all([
    db
      .select({
        year: schema.seasons.year,
        isCurrent: schema.seasons.isCurrent,
      })
      .from(schema.seasons)
      .where(eq(schema.seasons.competitionId, competitionId))
      .orderBy(desc(schema.seasons.year)),
    db
      .select({
        seasonYear: schema.fixtures.seasonYear,
        count: sql<number>`count(*)`,
      })
      .from(schema.fixtures)
      .where(eq(schema.fixtures.competitionId, competitionId))
      .groupBy(schema.fixtures.seasonYear),
  ]);

  const fixtureCountByYear = new Map(fixtureCountRows.map((r) => [r.seasonYear, Number(r.count)]));
  const seasonsWithFixtures = new Set(fixtureCountRows.map((r) => r.seasonYear));

  return rows
    .filter((r) => (r.isCurrent ?? false) || seasonsWithFixtures.has(r.year))
    .map((r) => ({
      year: r.year,
      isCurrent: r.isCurrent ?? false,
      fixtureCount: fixtureCountByYear.get(r.year) ?? 0,
    }));
}

export async function getLeagueRounds(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
): Promise<RoundInfo[]> {
  const rows = await db
    .selectDistinctOn([schema.fixtures.roundNumber], {
      roundNumber: schema.fixtures.roundNumber,
      round: schema.fixtures.round,
    })
    .from(schema.fixtures)
    .where(
      and(
        eq(schema.fixtures.competitionId, competitionId),
        eq(schema.fixtures.seasonYear, seasonYear),
        sql`${schema.fixtures.roundNumber} IS NOT NULL`,
      ),
    )
    .orderBy(asc(schema.fixtures.roundNumber));

  return rows
    .filter((r): r is { roundNumber: number; round: string | null } => r.roundNumber != null)
    .map((r) => ({
      roundNumber: r.roundNumber,
      round: r.round ?? `Round ${r.roundNumber}`,
    }));
}

/**
 * Determine the "current" round.
 * Priority: round with live matches > most recent round with finished matches > first round.
 * Uses full status code sets + kickoff-time fallback for stale statuses.
 */
export async function getCurrentRound(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
): Promise<number | null> {
  const base = and(
    eq(schema.fixtures.competitionId, competitionId),
    eq(schema.fixtures.seasonYear, seasonYear),
    sql`${schema.fixtures.roundNumber} IS NOT NULL`,
  );

  // 1. Round with any live match — that's THE current round
  const live = await db
    .select({ roundNumber: schema.fixtures.roundNumber })
    .from(schema.fixtures)
    .where(and(base, inArray(schema.fixtures.statusCode, [...LIVE_CODES_ARRAY])))
    .orderBy(desc(schema.fixtures.roundNumber))
    .limit(1);

  if (live[0]?.roundNumber != null) return live[0].roundNumber;

  // 2. Most recent round with a finished match (explicit codes OR stale status with past kickoff)
  const finished = await db
    .select({ roundNumber: schema.fixtures.roundNumber })
    .from(schema.fixtures)
    .where(
      and(
        base,
        sql`(${schema.fixtures.statusCode} IN (${sql.join(
          FINISHED_CODES_ARRAY.map((c) => sql`${c}`),
          sql`, `,
        )}) OR (${schema.fixtures.kickoffAt} <= NOW() AND ${schema.fixtures.statusCode} NOT IN (${sql.join(
          LIVE_CODES_ARRAY.map((c) => sql`${c}`),
          sql`, `,
        )})))`,
      ),
    )
    .orderBy(desc(schema.fixtures.roundNumber))
    .limit(1);

  if (finished[0]?.roundNumber != null) return finished[0].roundNumber;

  // 3. Fallback: first round with any match
  const first = await db
    .select({ roundNumber: schema.fixtures.roundNumber })
    .from(schema.fixtures)
    .where(base)
    .orderBy(asc(schema.fixtures.roundNumber))
    .limit(1);

  return first[0]?.roundNumber ?? null;
}

/**
 * Featured match for a league: next upcoming fixture, or most recent finished.
 */
export async function getLeagueFeaturedMatch(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
): Promise<FixtureWithTeams | null> {
  const matches = await getLeagueFeaturedMatches(db, competitionId, seasonYear, 1);
  return matches[0] ?? null;
}

/**
 * Best N matches for the current/next matchweek.
 * Priority: live > upcoming > most recent finished.
 * Uses full status code sets + kickoff-time fallback for stale statuses.
 */
export async function getLeagueFeaturedMatches(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
  limit = 2,
): Promise<FixtureWithTeams[]> {
  const base = and(
    eq(schema.fixtures.competitionId, competitionId),
    eq(schema.fixtures.seasonYear, seasonYear),
  );

  // 1. Live matches first
  const live = await db
    .select()
    .from(schema.fixtures)
    .where(and(base, inArray(schema.fixtures.statusCode, [...LIVE_CODES_ARRAY])))
    .orderBy(asc(schema.fixtures.kickoffAt))
    .limit(limit);

  if (live.length >= limit) {
    return hydrateFixtures(db, live.slice(0, limit));
  }

  const collected = [...live];

  // 2. Fill with upcoming (future kickoff, not live, not finished)
  if (collected.length < limit) {
    const upcoming = await db
      .select()
      .from(schema.fixtures)
      .where(
        and(
          base,
          sql`${schema.fixtures.kickoffAt} > NOW()`,
          sql`${schema.fixtures.statusCode} NOT IN (${sql.join(
            [...LIVE_CODES_ARRAY, ...FINISHED_CODES_ARRAY].map((c) => sql`${c}`),
            sql`, `,
          )})`,
        ),
      )
      .orderBy(asc(schema.fixtures.kickoffAt))
      .limit(limit - collected.length);

    collected.push(...upcoming);
  }

  // 3. Fill remaining with most recent finished
  if (collected.length < limit) {
    const recent = await db
      .select()
      .from(schema.fixtures)
      .where(
        and(
          base,
          sql`(${schema.fixtures.statusCode} IN (${sql.join(
            FINISHED_CODES_ARRAY.map((c) => sql`${c}`),
            sql`, `,
          )}) OR (${schema.fixtures.kickoffAt} <= NOW() AND ${schema.fixtures.statusCode} NOT IN (${sql.join(
            LIVE_CODES_ARRAY.map((c) => sql`${c}`),
            sql`, `,
          )})))`,
        ),
      )
      .orderBy(desc(schema.fixtures.kickoffAt))
      .limit(limit - collected.length);

    collected.push(...recent);
  }

  if (collected.length === 0) return [];
  return hydrateFixtures(db, collected);
}

/**
 * All fixtures for a league season, ordered by kickoff.
 * Used by LeagueFixturesCard which handles client-side round filtering.
 * Pass `limit` to cap results (default 500 as safety bound).
 */
export async function getLeagueFixtures(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
  opts: { limit?: number; offset?: number } = {},
): Promise<FixtureWithTeams[]> {
  const { limit = 500, offset = 0 } = opts;

  let query = db
    .select()
    .from(schema.fixtures)
    .where(
      and(
        eq(schema.fixtures.competitionId, competitionId),
        eq(schema.fixtures.seasonYear, seasonYear),
      ),
    )
    .orderBy(asc(schema.fixtures.roundNumber), asc(schema.fixtures.kickoffAt))
    .limit(limit)
    .$dynamic();

  if (offset > 0) {
    query = query.offset(offset);
  }

  const rows = await query;
  return hydrateFixtures(db, rows);
}

// ── Top scorers / assists ──

export interface TopPlayerRow {
  playerId: number;
  playerSlug: string;
  playerName: string;
  playerPhoto: string | null;
  teamName: string;
  teamLogo: string | null;
  goals: number;
  assists: number;
}

export async function getTopScorersForLeague(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
  limit = 10,
): Promise<TopPlayerRow[]> {
  const rows = await db
    .select({
      playerId: schema.playerSeasonStats.playerId,
      playerSlug: schema.players.slug,
      stats: schema.playerSeasonStats.stats,
    })
    .from(schema.playerSeasonStats)
    .innerJoin(schema.players, eq(schema.playerSeasonStats.playerId, schema.players.id))
    .where(
      and(
        eq(schema.playerSeasonStats.competitionId, competitionId),
        eq(schema.playerSeasonStats.seasonYear, seasonYear),
      ),
    )
    .orderBy(sql`(${schema.playerSeasonStats.stats}->>'goals')::int DESC NULLS LAST`)
    .limit(limit);

  return rows.map((r) => {
    const s = r.stats as Record<string, unknown>;
    return {
      playerId: r.playerId,
      playerSlug: r.playerSlug,
      playerName: (s.playerName as string) ?? '',
      playerPhoto: (s.playerPhoto as string) ?? null,
      teamName: (s.teamName as string) ?? '',
      teamLogo: (s.teamLogo as string) ?? null,
      goals: Number(s.goals) || 0,
      assists: Number(s.assists) || 0,
    };
  });
}

export async function getTopAssistsForLeague(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
  limit = 10,
): Promise<TopPlayerRow[]> {
  const rows = await db
    .select({
      playerId: schema.playerSeasonStats.playerId,
      playerSlug: schema.players.slug,
      stats: schema.playerSeasonStats.stats,
    })
    .from(schema.playerSeasonStats)
    .innerJoin(schema.players, eq(schema.playerSeasonStats.playerId, schema.players.id))
    .where(
      and(
        eq(schema.playerSeasonStats.competitionId, competitionId),
        eq(schema.playerSeasonStats.seasonYear, seasonYear),
      ),
    )
    .orderBy(sql`(${schema.playerSeasonStats.stats}->>'assists')::int DESC NULLS LAST`)
    .limit(limit);

  return rows.map((r) => {
    const s = r.stats as Record<string, unknown>;
    return {
      playerId: r.playerId,
      playerSlug: r.playerSlug,
      playerName: (s.playerName as string) ?? '',
      playerPhoto: (s.playerPhoto as string) ?? null,
      teamName: (s.teamName as string) ?? '',
      teamLogo: (s.teamLogo as string) ?? null,
      goals: Number(s.goals) || 0,
      assists: Number(s.assists) || 0,
    };
  });
}

/**
 * Top scorers for a single tournament edition, computed from this edition's goal events
 * (`fixture_events`) rather than `player_season_stats`. For short-edition cups the upstream
 * /players/topscorers feed is unreliable (returns non-participants/qualifier data), whereas the
 * ingested goal events are accurate. Own goals are excluded; penalties count. Names/teams come from
 * the canonical `players`/`teams` tables (localized), avoiding the stats-JSON HTML entities.
 */
export async function getEditionTopScorers(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
  locale: string,
  limit = 5,
): Promise<TopPlayerRow[]> {
  const res = await db.execute(sql`
    SELECT p.id AS player_id, p.slug AS player_slug,
           COALESCE(p.name->>${locale}, p.name->>'en') AS player_name,
           p.photo_url AS player_photo,
           COALESCE(t.name->>${locale}, t.name->>'en') AS team_name,
           t.logo_url AS team_logo,
           COUNT(*)::int AS goals
    FROM fixture_events e
    JOIN fixtures f ON f.id = e.fixture_id
    JOIN players p ON p.id = e.player_id
    LEFT JOIN teams t ON t.id = e.team_id
    WHERE f.competition_id = ${competitionId}
      AND f.season_year = ${seasonYear}
      AND e.type = 'Goal'
      AND e.detail IN ('Normal Goal', 'Penalty')
    GROUP BY p.id, t.id
    ORDER BY goals DESC, p.slug
    LIMIT ${limit}
  `);
  return (res.rows as Array<Record<string, unknown>>).map((r) => ({
    playerId: Number(r.player_id),
    playerSlug: r.player_slug as string,
    playerName: (r.player_name as string) ?? '',
    playerPhoto: (r.player_photo as string) ?? null,
    teamName: (r.team_name as string) ?? '',
    teamLogo: (r.team_logo as string) ?? null,
    goals: Number(r.goals) || 0,
    assists: 0,
  }));
}

/** Top assisters for a single edition, computed from goal-event `assist_player_id`. See {@link getEditionTopScorers}. */
export async function getEditionTopAssists(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
  locale: string,
  limit = 5,
): Promise<TopPlayerRow[]> {
  const res = await db.execute(sql`
    SELECT p.id AS player_id, p.slug AS player_slug,
           COALESCE(p.name->>${locale}, p.name->>'en') AS player_name,
           p.photo_url AS player_photo,
           COALESCE(t.name->>${locale}, t.name->>'en') AS team_name,
           t.logo_url AS team_logo,
           COUNT(*)::int AS assists
    FROM fixture_events e
    JOIN fixtures f ON f.id = e.fixture_id
    JOIN players p ON p.id = e.assist_player_id
    LEFT JOIN teams t ON t.id = e.team_id
    WHERE f.competition_id = ${competitionId}
      AND f.season_year = ${seasonYear}
      AND e.type = 'Goal'
      AND e.detail IN ('Normal Goal', 'Penalty')
      AND e.assist_player_id IS NOT NULL
    GROUP BY p.id, t.id
    ORDER BY assists DESC, p.slug
    LIMIT ${limit}
  `);
  return (res.rows as Array<Record<string, unknown>>).map((r) => ({
    playerId: Number(r.player_id),
    playerSlug: r.player_slug as string,
    playerName: (r.player_name as string) ?? '',
    playerPhoto: (r.player_photo as string) ?? null,
    teamName: (r.team_name as string) ?? '',
    teamLogo: (r.team_logo as string) ?? null,
    goals: 0,
    assists: Number(r.assists) || 0,
  }));
}

/**
 * Top scorers preferring the official `/topscorers` aggregate, but falling back to goal events when
 * that feed is broken/empty for a season — it sometimes fails to populate (e.g. Botola 2025 had
 * 4 scorers / max 3 goals while 372 goals were on record in `fixture_events`). Picks whichever
 * source's leader has more goals (the one that isn't undercounting) and drops 0-goal players so a
 * sparse aggregate never pads the list. Healthy leagues keep their canonical aggregate.
 */
export async function getResolvedTopScorers(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
  locale: string,
  limit = 10,
): Promise<TopPlayerRow[]> {
  const [official, events] = await Promise.all([
    getTopScorersForLeague(db, competitionId, seasonYear, limit),
    getEditionTopScorers(db, competitionId, seasonYear, locale, limit),
  ]);
  const chosen = (official[0]?.goals ?? 0) >= (events[0]?.goals ?? 0) ? official : events;
  return chosen.filter((p) => p.goals > 0);
}

/** Top assists with the same official-then-events fallback as {@link getResolvedTopScorers}. */
export async function getResolvedTopAssists(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
  locale: string,
  limit = 10,
): Promise<TopPlayerRow[]> {
  const [official, events] = await Promise.all([
    getTopAssistsForLeague(db, competitionId, seasonYear, limit),
    getEditionTopAssists(db, competitionId, seasonYear, locale, limit),
  ]);
  const chosen = (official[0]?.assists ?? 0) >= (events[0]?.assists ?? 0) ? official : events;
  return chosen.filter((p) => p.assists > 0);
}

// ── Top cards ──

export interface TopCardRow {
  playerId: number;
  playerSlug: string;
  playerName: string;
  playerPhoto: string | null;
  teamName: string;
  teamLogo: string | null;
  yellowCards: number;
  redCards: number;
}

export async function getTopCardsForLeague(
  db: NeonHttpDatabase<typeof schema>,
  competitionId: number,
  seasonYear: number,
  limit = 10,
): Promise<TopCardRow[]> {
  const rows = await db
    .select({
      playerId: schema.playerSeasonStats.playerId,
      playerSlug: schema.players.slug,
      stats: schema.playerSeasonStats.stats,
    })
    .from(schema.playerSeasonStats)
    .innerJoin(schema.players, eq(schema.playerSeasonStats.playerId, schema.players.id))
    .where(
      and(
        eq(schema.playerSeasonStats.competitionId, competitionId),
        eq(schema.playerSeasonStats.seasonYear, seasonYear),
      ),
    )
    .orderBy(sql`(${schema.playerSeasonStats.stats}->>'yellowCards')::int DESC NULLS LAST`)
    .limit(limit);

  return rows.map((r) => {
    const s = r.stats as Record<string, unknown>;
    return {
      playerId: r.playerId,
      playerSlug: r.playerSlug,
      playerName: (s.playerName as string) ?? '',
      playerPhoto: (s.playerPhoto as string) ?? null,
      teamName: (s.teamName as string) ?? '',
      teamLogo: (s.teamLogo as string) ?? null,
      yellowCards: Number(s.yellowCards) || 0,
      redCards: Number(s.redCards) || 0,
    };
  });
}
