import { beforeAll, afterAll, afterEach } from 'vitest';
import { server } from './data/mocks/server';

beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());
