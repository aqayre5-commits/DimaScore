import { NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { getDataProvider } from '@/lib/data';
import { verifyCronSecret } from '@/lib/cron/auth';
import { syncFixtures } from '@/lib/ingestion/fixtures';
import { getCurrentSeasons } from '@/lib/db/queries';

export async function GET(request: Request) {
  if (!verifyCronSecret(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const provider = getDataProvider();
    const currentSeasons = await getCurrentSeasons(db);

    const results: { competitionId: number; season: number; updated: number }[] = [];
    const errors: { competitionId: number; season: number; error: string }[] = [];

    // Per-competition isolation: one failing competition must not abort the whole run — critical at
    // season rollover, when several leagues switch season at once.
    for (const cs of currentSeasons) {
      try {
        const stats = await syncFixtures(provider, db, {
          leagueId: cs.competitionId,
          season: cs.year,
          isWomen: cs.isWomen,
        });
        results.push({
          competitionId: cs.competitionId,
          season: cs.year,
          updated: stats.updated,
        });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(
          `Cron fixtures-schedule: competition ${cs.competitionId} season ${cs.year} failed:`,
          error,
        );
        errors.push({ competitionId: cs.competitionId, season: cs.year, error: message });
      }
    }

    return NextResponse.json({
      ok: true,
      synced: results.length,
      failed: errors.length,
      results,
      errors,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error('Cron fixtures-schedule failed:', error);
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}
