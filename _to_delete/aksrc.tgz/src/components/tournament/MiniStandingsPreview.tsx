'use client';

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { Flag } from '@/components/shared/Flag';
import { stripWomenSuffix } from '@/lib/team-display';
import { FormPills } from '@/components/shared/FormPills';
import type { StandingRow } from '@/lib/db/queries';
import type { Locale } from '@/lib/i18n/config';

import { cn } from '@/lib/utils';

interface MiniStandingsPreviewProps {
  standings: StandingRow[];
  locale: Locale;
  defaultGroup: string;
  moroccoGroupLabel?: string | null;
  groupLabels: string[];
  standingsHash: string;
}

/**
 * Overview Block 2 — Mini standings preview with group selector.
 * Per competition-cup.md Section 7 Tab 1 Block 2.
 * "All" view renders each group as its own card with id + ShareButton.
 * Single-group view renders one card. "View all groups" links to Standings tab.
 */
export function MiniStandingsPreview({
  standings,
  locale,
  defaultGroup,
  moroccoGroupLabel,
  groupLabels,
  standingsHash,
}: MiniStandingsPreviewProps) {
  const t = useTranslations('tournament');
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);

  // Group standings by normalized label
  const standingsByGroup = new Map<string, StandingRow[]>();
  for (const row of standings) {
    const arr = standingsByGroup.get(row.groupLabel) ?? [];
    arr.push(row);
    standingsByGroup.set(row.groupLabel, arr);
  }

  const visibleGroups = selectedGroup ? [selectedGroup] : groupLabels;

  return (
    <div className="space-y-3">
      {/* Header: title + selector */}
      <div className="flex items-center justify-between">
        <h3 className="label-caps">{t('standingsPreview')}</h3>
        <select
          value={selectedGroup ?? ''}
          onChange={(e) => setSelectedGroup(e.target.value || null)}
          className="rounded border border-border-subtle bg-bg-surface-2 px-2 py-1 text-xs text-text-secondary"
        >
          <option value="">{t('all')}</option>
          {groupLabels.map((label) => (
            <option key={label} value={label}>
              {t('groupLabel', { label })}
            </option>
          ))}
        </select>
      </div>

      {/* Group cards */}
      {visibleGroups.map((groupLabel) => {
        const groupRows = standingsByGroup.get(groupLabel) ?? [];
        const isMoroccoGroup = moroccoGroupLabel != null && groupLabel === moroccoGroupLabel;
        const groupHash = `group-${groupLabel.toLowerCase()}`;

        return (
          <div
            key={groupLabel}
            id={groupHash}
            className="rounded-lg border border-border-subtle bg-bg-surface"
          >
            {/* Group header */}
            <div className="border-b border-border-subtle px-4 py-2">
              <div
                className={cn(
                  'text-xs font-semibold',
                  isMoroccoGroup ? 'text-accent-azure' : 'text-text-primary',
                )}
              >
                {t('groupLabel', { label: groupLabel })}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border-subtle text-xs text-text-secondary">
                    <th scope="col" className="w-5 py-1 pl-4 text-start font-medium md:pl-6">
                      #
                    </th>
                    <th scope="col" className="py-1 text-start font-medium">
                      {t('team')}
                    </th>
                    <th scope="col" className="w-6 py-1 text-center font-medium">
                      {t('colPlayed')}
                    </th>
                    <th scope="col" className="w-6 py-1 text-center font-medium">
                      {t('colWon')}
                    </th>
                    <th scope="col" className="w-6 py-1 text-center font-medium">
                      {t('colDrawn')}
                    </th>
                    <th scope="col" className="w-6 py-1 text-center font-medium">
                      {t('colLost')}
                    </th>
                    <th scope="col" className="w-6 py-1 text-center font-medium">
                      {t('colGoalsFor')}
                    </th>
                    <th scope="col" className="w-6 py-1 text-center font-medium">
                      {t('colGoalsAgainst')}
                    </th>
                    <th scope="col" className="w-7 py-1 text-center font-medium">
                      {t('colGoalDiff')}
                    </th>
                    <th scope="col" className="w-7 py-1 text-center font-semibold">
                      {t('colPoints')}
                    </th>
                    <th scope="col" className="w-16 py-1 text-center font-medium">
                      {t('colForm')}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {groupRows.map((row) => {
                    const teamName = stripWomenSuffix(
                      row.team?.name[locale] ??
                        row.team?.name['en'] ??
                        row.team?.shortName[locale] ??
                        row.team?.code ??
                        '\u2014',
                    );
                    const isMorocco = row.team?.code === 'MA';

                    return (
                      <tr
                        key={row.teamId}
                        className={cn(
                          'border-b border-border-subtle last:border-b-0',
                          isMorocco && 'font-semibold',
                        )}
                      >
                        <td className="py-1.5 pl-4 pr-2 text-start tabular-nums text-text-secondary md:pl-6">
                          {row.rank}
                        </td>
                        <td className="py-1.5">
                          <span className="flex items-center gap-2">
                            <Flag
                              countryCode={row.team?.countryCode}
                              logoUrl={row.team?.logoUrl}
                              isNational={row.team?.isNational}
                              size={16}
                              label={row.team?.code}
                              className="shrink-0"
                            />
                            <span
                              className={cn(
                                'overflow-hidden text-ellipsis whitespace-nowrap text-sm',
                                isMorocco ? 'text-accent-azure' : 'text-text-secondary',
                              )}
                            >
                              {teamName}
                            </span>
                          </span>
                        </td>
                        <td className="py-1.5 text-center tabular-nums text-text-secondary">
                          {row.played}
                        </td>
                        <td className="py-1.5 text-center tabular-nums text-text-secondary">
                          {row.won ?? 0}
                        </td>
                        <td className="py-1.5 text-center tabular-nums text-text-secondary">
                          {row.drawn ?? 0}
                        </td>
                        <td className="py-1.5 text-center tabular-nums text-text-secondary">
                          {row.lost ?? 0}
                        </td>
                        <td className="py-1.5 text-center tabular-nums text-text-secondary">
                          {row.goalsFor ?? 0}
                        </td>
                        <td className="py-1.5 text-center tabular-nums text-text-secondary">
                          {row.goalsAgainst ?? 0}
                        </td>
                        <td className="py-1.5 text-center tabular-nums text-text-secondary">
                          {row.goalDiff ?? 0}
                        </td>
                        <td
                          className={cn(
                            'py-1.5 text-center tabular-nums font-semibold',
                            isMorocco ? 'text-accent-azure' : 'text-text-primary',
                          )}
                        >
                          {row.points}
                        </td>
                        <td className="py-1.5 text-center">
                          <FormPills
                            form={row.form}
                            formLabels={{ W: t('formWin'), D: t('formDraw'), L: t('formLoss') }}
                            count={row.played ?? 5}
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        );
      })}

      {/* Footer link */}
      <button
        onClick={() => {
          window.location.hash = standingsHash;
          window.dispatchEvent(new HashChangeEvent('hashchange'));
        }}
        className="inline-flex min-h-[44px] items-center text-xs font-medium text-accent-azure hover:text-accent-azure/80"
      >
        {t('viewAllGroups')} &rarr;
      </button>
    </div>
  );
}
