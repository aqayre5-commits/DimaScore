import Link from 'next/link';
import type { StandingRow } from '@/lib/db/queries';
import { dedupeStandingsByTeam } from '@/lib/standings/dedupe';
import { getTeamDisplayName } from '@/lib/utils/team-name';
import type { Locale } from '@/lib/i18n/config';
import { Flag } from '@/components/shared/Flag';

interface StandingsWidgetProps {
  heading: string;
  rows: StandingRow[];
  viewAllHref: string;
  viewAllLabel: string;
  locale: Locale;
  rankLabel: string;
  teamLabel: string;
  playedLabel: string;
  pointsLabel: string;
}

export function StandingsWidget({
  heading,
  rows,
  viewAllHref,
  viewAllLabel,
  locale,
  rankLabel,
  teamLabel,
  playedLabel,
  pointsLabel,
}: StandingsWidgetProps) {
  const top6 = dedupeStandingsByTeam(rows).slice(0, 6);

  return (
    <div className="overflow-hidden rounded-xl border border-border-subtle bg-bg-surface">
      <div className="px-3 pt-3 pb-2">
        <h2 className="text-base font-semibold text-text-primary">{heading}</h2>
      </div>

      {top6.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border-subtle text-text-tertiary">
                <th className="w-8 py-1.5 text-center font-medium">{rankLabel}</th>
                <th className="py-1.5 text-start font-medium">{teamLabel}</th>
                <th className="w-10 py-1.5 text-center font-medium">{playedLabel}</th>
                <th className="w-10 py-1.5 text-center font-medium">{pointsLabel}</th>
              </tr>
            </thead>
            <tbody>
              {top6.map((row, idx) => (
                <tr
                  key={row.teamId ?? idx}
                  className="border-b border-border-subtle last:border-b-0"
                >
                  <td className="py-1.5 text-center tabular-nums text-text-tertiary">{row.rank}</td>
                  <td className="py-1.5">
                    <div className="flex items-center gap-1.5">
                      <Flag
                        countryCode={row.team?.countryCode}
                        logoUrl={row.team?.logoUrl}
                        isNational={row.team?.isNational}
                        size={16}
                        label={row.team?.code}
                        className="shrink-0"
                      />
                      <span className="truncate text-text-primary">
                        {getTeamDisplayName(row.team, locale)}
                      </span>
                    </div>
                  </td>
                  <td className="py-1.5 text-center tabular-nums text-text-secondary">
                    {row.played}
                  </td>
                  <td className="py-1.5 text-center tabular-nums font-semibold text-text-primary">
                    {row.points}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="px-3 pb-3">
          <p className="text-xs text-text-tertiary">—</p>
        </div>
      )}

      <div className="border-t border-border-subtle px-3 py-2">
        <Link
          href={viewAllHref}
          className="text-sm font-medium text-accent-green transition-colors hover:text-accent-green/80"
        >
          {viewAllLabel} →
        </Link>
      </div>
    </div>
  );
}
