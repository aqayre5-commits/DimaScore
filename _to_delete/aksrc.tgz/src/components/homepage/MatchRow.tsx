'use client';

import type { DayFixture } from '@/lib/db/queries/fixtures-by-day';
import { getTeamDisplayName } from '@/lib/utils/team-name';
import { LocalTime } from '@/components/shared/LocalTime';
import { getMatchState, getMatchStatusLabelKey } from '@/lib/match-status';
import { useTranslations } from 'next-intl';
import { MatchLink } from '@/components/shared/MatchLink';
import { previewFromDayFixture } from '@/lib/match-header-preview';
import type { Locale } from '@/lib/i18n/config';
import { Flag } from '@/components/shared/Flag';
import { useLiveFixtures } from '@/hooks/useLiveFixtures';

interface MatchRowProps {
  fixture: DayFixture;
  locale: string;
  enablePrefetch?: boolean;
  competition?: { name: Record<string, string>; slug: string } | null;
}

export function MatchRow({ fixture: f, locale, enablePrefetch, competition }: MatchRowProps) {
  // Overlay the shared 15s live poll so scores/minute/status track the real match state
  // without a page reload (FixtureListClient ancestor doesn't subscribe today).
  const patch = useLiveFixtures().get(f.id);
  const fixture: DayFixture = patch
    ? {
        ...f,
        statusCode: patch.statusCode,
        minute: patch.minute,
        homeScore: patch.homeScore,
        awayScore: patch.awayScore,
        homeScorePen: patch.homeScorePen,
        awayScorePen: patch.awayScorePen,
      }
    : f;

  const t = useTranslations('matchDetail');
  const state = getMatchState(fixture.statusCode, fixture.kickoffAt);
  const isLive = state === 'live';
  const isFinished = state === 'finished';
  const isInterrupted = state === 'interrupted';
  const interruptedKey = getMatchStatusLabelKey(fixture.statusCode);
  const showPenScore =
    fixture.statusCode === 'PEN' && fixture.homeScorePen != null && fixture.awayScorePen != null;

  const homeLabel = getTeamDisplayName(fixture.homeTeam, locale);
  const awayLabel = getTeamDisplayName(fixture.awayTeam, locale);

  const nameCls = isLive ? 'font-medium text-text-primary' : 'text-text-primary';

  const preview = previewFromDayFixture(fixture, competition);

  return (
    <MatchLink
      matchId={String(fixture.id)}
      href={`/${locale}/match/${fixture.id}`}
      preview={preview}
      prefetchIntent={enablePrefetch}
      ariaLabel={`${homeLabel} vs ${awayLabel}`}
      className="flex items-center gap-2 border-b border-border-subtle px-3 py-2 text-base transition-colors hover:bg-bg-surface-2"
    >
      {/* Time / status */}
      <div className="w-12 shrink-0 text-center">
        {isLive ? (
          <span className="flex items-center justify-center gap-1 text-xs font-bold text-score-live">
            <span className="live-pulse size-1.5 rounded-full bg-score-live" />
            {fixture.statusCode === 'HT'
              ? 'HT'
              : fixture.minute != null
                ? `${fixture.minute}'`
                : fixture.statusCode === 'P'
                  ? 'PEN'
                  : fixture.statusCode}
          </span>
        ) : isFinished ? (
          <span className="text-xs text-text-tertiary">
            {fixture.statusCode === 'AET' ? 'AET' : 'FT'}
          </span>
        ) : (
          <span className="text-xs tabular-nums text-text-secondary">
            <LocalTime date={fixture.kickoffAt} locale={locale as Locale} format="time" />
          </span>
        )}
      </div>

      {/* Home team */}
      <div className="flex min-w-0 flex-1 items-center justify-end gap-1.5">
        <span className={`overflow-hidden text-ellipsis whitespace-nowrap text-base ${nameCls}`}>
          {homeLabel}
        </span>
        <Flag
          countryCode={fixture.homeTeam?.countryCode}
          logoUrl={fixture.homeTeam?.logoUrl}
          isNational={fixture.homeTeam?.isNational}
          size={16}
          label={fixture.homeTeam?.code}
          className="shrink-0"
        />
      </div>

      {/* Score (+ pen score beneath) or vs */}
      <div className="flex w-12 shrink-0 flex-col items-center justify-center text-center leading-tight tabular-nums">
        {fixture.homeScore != null && fixture.awayScore != null ? (
          <span
            className={`text-sm font-semibold ${isLive ? 'text-score-live' : 'text-text-primary'}`}
          >
            {fixture.homeScore} - {fixture.awayScore}
          </span>
        ) : isInterrupted ? (
          <span className="text-[10px] font-medium leading-tight text-text-tertiary">
            {interruptedKey ? t(interruptedKey) : 'vs'}
          </span>
        ) : (
          <span className="text-xs text-text-tertiary">{isFinished ? '–' : 'vs'}</span>
        )}
        {showPenScore && (
          <span className="whitespace-nowrap text-[10px] font-semibold uppercase text-text-tertiary">
            PEN {fixture.homeScorePen}-{fixture.awayScorePen}
          </span>
        )}
      </div>

      {/* Away team */}
      <div className="flex min-w-0 flex-1 items-center gap-1.5">
        <Flag
          countryCode={fixture.awayTeam?.countryCode}
          logoUrl={fixture.awayTeam?.logoUrl}
          isNational={fixture.awayTeam?.isNational}
          size={16}
          label={fixture.awayTeam?.code}
          className="shrink-0"
        />
        <span className={`overflow-hidden text-ellipsis whitespace-nowrap text-base ${nameCls}`}>
          {awayLabel}
        </span>
      </div>
    </MatchLink>
  );
}
